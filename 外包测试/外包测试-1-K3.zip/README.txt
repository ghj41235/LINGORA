luoxiaohei（罗小黑）纯符号认知 AI —— 完整源码 + 种子数据 + 任务手册。

任务手册：先读「外包测试-1-手册-KimiK3.md」，再读「外包测试-0-规范.md」。
一句话任务：写 verify_speaking.py，用 subprocess 驱动运行时，
验证「不同输入 → 不同输出」，而非所有输入都卡在同一条。

运行方式（在解压后的项目根目录）：
    python -m src.runtime.main --file tmp_verify.luoxiaohei --new

铁律：src/core/__init__.py 顶部是宪法（禁区清单），禁止一切神经网络技术，
你写的代码绝不能出现那些被禁的词/概念/模式。
