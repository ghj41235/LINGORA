luoxiaohei（罗小黑）纯符号认知 AI —— 被测文件最小子集 + 任务手册。

任务手册：先读「外包测试-2-手册-Claude网页版.md」，再读「外包测试-0-规范.md」。
一句话任务：给 src/core/evidence.py 写单元测试 test_evidence.py + 找边界 bug。
被测对象：truth_expectation / revise_evidence 两个纯函数，
以及调用方 update_evidence_after_conduction。
Key 对象的 evidence_freq / evidence_conf 字段见 src/core/key.py。

铁律：src/core/__init__.py 顶部是宪法（禁区清单），禁止一切神经网络技术。
