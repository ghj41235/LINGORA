luoxiaohei（罗小黑）—— evidence.py 修复任务。

任务手册：读「外包测试-3-修复手册-Claude网页版.md」。
一句话：只修 evidence.py 的 3 个隐患（deltas 漏记 / frequency 没 clamp / 短路绕开下限），
4/5/6 别动；同时把对应的 test_hazard_* 用例改成断言修复后行为，30 个测试仍全绿。

运行（解压后，src/core/ 目录）：
    python3 -m unittest test_evidence -v

铁律：src/core/__init__.py 顶部是宪法（禁区清单），禁止一切神经网络技术。
